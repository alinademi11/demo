<?php
	// правильно настройте переменные подключения
	// !!! --> ваши настройки могут отличаться
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpassword = "";
	$dbname = "db_demo_2021";