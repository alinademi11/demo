<footer>
			<div class="content">
			</div>
		</footer>

	</body>
</html>