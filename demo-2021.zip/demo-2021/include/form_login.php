<div class="heading" id="login">Вход</div>

<!-- форма авторизации -->
<form action="service/login.php" method="POST">
	<!-- логин -->
	<input type="text" placeholder="Логин" name="login">
	<!-- пароль -->
	<input type="password" placeholder="Пароль" name="password">
	<!-- кнопка входа -->
	<input type="submit" value="Войти">
</form>